import React from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, Phone, Mail, Award, ShieldAlert, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { t } = useApp();

  return (
    <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-800">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          
          {/* Column 1: Government details */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 font-bold text-white shadow-md">
                GLO
              </div>
              <div>
                <h4 className="text-sm font-black text-white tracking-tight uppercase">
                  {t('appName')}
                </h4>
                <p className="text-[10px] text-amber-500 font-bold tracking-wider uppercase">
                  Sovereign Portal
                </p>
              </div>
            </div>
            
            <p className="text-[11px] text-slate-400 leading-relaxed">
              The official portal for security-certified digital drawings and ticket auditing. Managed under national auditing ledgers.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h5 className="text-xs font-bold text-white uppercase tracking-wider">Quick Navigation</h5>
            <ul className="text-xs space-y-2">
              <li>
                <a href="#hero" className="hover:text-amber-500 transition-colors">Home Portal</a>
              </li>
              <li>
                <a href="#checker" className="hover:text-amber-500 transition-colors">Results Checking System</a>
              </li>
              <li>
                <a href="#news" className="hover:text-amber-500 transition-colors">GLO Announcements</a>
              </li>
              <li>
                <a href="#stats" className="hover:text-amber-500 transition-colors">Ecosystem Statistics</a>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact & Support */}
          <div className="space-y-3">
            <h5 className="text-xs font-bold text-white uppercase tracking-wider">Official Contacts</h5>
            <div className="text-xs space-y-2.5">
              <p className="flex items-start gap-2 leading-relaxed">
                <MapPin className="h-4.5 w-4.5 text-amber-500 flex-shrink-0 mt-0.5" />
                <span>{t('lblFooterAddress')}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="h-4.5 w-4.5 text-amber-500 flex-shrink-0" />
                <span>+66 2624 4300</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="h-4.5 w-4.5 text-amber-500 flex-shrink-0" />
                <span>support@glo.or.th</span>
              </p>
              <div className="pt-2 border-t border-slate-800 space-y-1.5">
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">IMO Contact Helplines</p>
                <p className="flex items-center gap-2 text-amber-500 font-extrabold font-mono">
                  <span className="bg-amber-500 text-slate-950 px-1 py-0.5 rounded text-[8px] font-black uppercase tracking-widest font-sans">IMO BD</span>
                  <span>+8801861669929</span>
                </p>
                <p className="flex items-center gap-2 text-amber-500 font-extrabold font-mono">
                  <span className="bg-amber-500 text-slate-950 px-1 py-0.5 rounded text-[8px] font-black uppercase tracking-widest font-sans">IMO TH</span>
                  <span>+66863870227</span>
                </p>
              </div>
            </div>
          </div>

          {/* Column 4: Certified Badges */}
          <div className="space-y-3">
            <h5 className="text-xs font-bold text-white uppercase tracking-wider">Compliance & Trust</h5>
            <div className="space-y-3">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-start gap-2.5">
                <Award className="h-5 w-5 text-amber-500 flex-shrink-0" />
                <p className="text-[10px] text-slate-350 leading-relaxed">
                  Certified ISO/IEC 27001 Security Management System.
                </p>
              </div>
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-start gap-2.5">
                <ShieldAlert className="h-5 w-5 text-amber-500 flex-shrink-0" />
                <p className="text-[10px] text-slate-350 leading-relaxed">
                  GLO Anti-Fraud auditing protocols applied.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Rights */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center">
          <p className="text-[11px]">
            {t('lblFooterRights')}
          </p>
          <div className="flex gap-4 text-[10px] uppercase font-bold text-slate-500">
            <a href="#" className="hover:text-amber-500 transition-colors">Terms of Service</a>
            <span>•</span>
            <a href="#" className="hover:text-amber-500 transition-colors">Privacy Policy</a>
            <span>•</span>
            <a href="#" className="hover:text-amber-500 transition-colors">Cookie Policy</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
