import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Bot, Send, X, MessageSquare, Sparkles } from 'lucide-react';

interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
  time: string;
}

export const GeminiBot: React.FC = () => {
  const { language, t } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'bot',
      text: 'Hello! I am your GLO AI Assistant. How can I help you today? You can ask me about drawing schedules, prize claim procedures, digital tickets, or past statistics.',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const quickPrompts = [
    'How do I claim lottery prizes?',
    'When is the next drawing?',
    'What is the ticket price?'
  ];

  const handleSend = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      sender: 'user',
      text: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });

      const data = await response.json();
      const botMsg: ChatMessage = {
        sender: 'bot',
        text: data.reply || 'I apologize, I am experiencing temporary connection issues. Please try again or query our FAQs.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      const errorMsg: ChatMessage = {
        sender: 'bot',
        text: 'I apologize, I am experiencing temporary connection issues. Please try again or query our FAQs.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      
      {/* Floating Action Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="h-14 w-14 rounded-full bg-slate-900 hover:bg-amber-500 text-amber-400 hover:text-slate-950 flex items-center justify-center shadow-2xl transition-all duration-300 relative group"
          id="chat-toggle-fab"
        >
          <Bot className="h-6 w-6" />
          <span className="absolute right-16 px-3 py-1 bg-slate-900 border border-slate-800 rounded-xl text-white text-[10px] font-bold uppercase tracking-wider whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-md">
            GLO AI Assistant
          </span>
        </button>
      )}

      {/* Floating Chat Panel */}
      {isOpen && (
        <div className="w-80 sm:w-96 h-[500px] bg-white border border-slate-200 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-fade-in">
          
          {/* Header */}
          <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-full bg-amber-500/10 text-amber-500 border border-amber-500/20 flex items-center justify-center">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-black tracking-tight flex items-center gap-1">
                  <span>GLO Smart Chatbot</span>
                  <Sparkles className="h-3 w-3 text-amber-400 animate-pulse" />
                </h4>
                <p className="text-[9px] text-slate-400 font-bold uppercase">Government AI Assistant</p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 hover:bg-slate-800 rounded-full text-slate-400 transition-colors"
              id="close-chat-panel-btn"
            >
              <X className="h-4.5 w-4.5" />
            </button>
          </div>

          {/* Messages list scrollable container */}
          <div 
            ref={scrollRef}
            className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/50"
          >
            {messages.map((msg, index) => (
              <div 
                key={index}
                className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'bot' && (
                  <div className="h-7 w-7 rounded-lg bg-slate-200 flex items-center justify-center text-slate-700 flex-shrink-0 text-xs">
                    🤖
                  </div>
                )}
                
                <div className={`max-w-[75%] p-3 rounded-2xl text-xs leading-relaxed font-sans shadow-sm ${msg.sender === 'user' ? 'bg-slate-900 text-white rounded-tr-none' : 'bg-white border border-slate-150 text-slate-800 rounded-tl-none'}`}>
                  <p>{msg.text}</p>
                  <span className="block text-[8px] text-slate-400 mt-1.5 text-right font-medium">
                    {msg.time}
                  </span>
                </div>
              </div>
            ))}

            {/* Loading typing indicator */}
            {loading && (
              <div className="flex items-start gap-2.5">
                <div className="h-7 w-7 rounded-lg bg-slate-200 flex items-center justify-center text-slate-700 flex-shrink-0 text-xs">
                  🤖
                </div>
                <div className="bg-white border border-slate-150 p-3 rounded-2xl rounded-tl-none flex items-center gap-1.5 shadow-sm">
                  <div className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-bounce" />
                  <div className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="h-1.5 w-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
          </div>

          {/* Footer controls */}
          <div className="p-3 bg-white border-t border-slate-100 flex flex-col gap-2 flex-shrink-0">
            
            {/* Quick Chips suggestions */}
            {messages.length === 1 && (
              <div className="flex flex-wrap gap-1.5 pb-1">
                {quickPrompts.map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSend(prompt)}
                    className="px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-150 text-[10px] font-bold text-slate-600 hover:bg-amber-50 hover:text-amber-700 hover:border-amber-300 transition-colors"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            )}

            {/* Search Input Box */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend(inputVal)}
                placeholder="Ask GLO AI..."
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none focus:bg-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                id="chat-text-input"
              />
              <button
                onClick={() => handleSend(inputVal)}
                className="p-2.5 bg-slate-900 hover:bg-amber-500 text-white hover:text-slate-950 rounded-xl transition-all shadow-sm flex items-center justify-center"
                id="chat-send-btn"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
