import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Pause, 
  Maximize2, 
  X, 
  Calendar, 
  MapPin, 
  Eye, 
  Tag 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GalleryItem {
  id: string;
  categoryEN: string;
  categoryTH: string;
  categoryBN: string;
  titleEN: string;
  titleTH: string;
  titleBN: string;
  descEN: string;
  descTH: string;
  descBN: string;
  date: string;
  locationEN: string;
  locationTH: string;
  locationBN: string;
  imageUrl: string;
  views: string;
}

const GALLERY_IMAGES: GalleryItem[] = [
  {
    id: 'gal-1',
    categoryEN: 'Broadcast & Operations',
    categoryTH: 'การออกรางวัลและถ่ายทอดสด',
    categoryBN: 'সম্প্রচার ও পরিচালনা',
    titleEN: 'GLO Live Draw Chamber & Technology',
    titleTH: 'ห้องออกรางวัลสลากกินแบ่งรัฐบาลและเทคโนโลยีความโปร่งใส',
    titleBN: 'জিএলও লাইভ ড্র চেম্বার এবং প্রযুক্তি',
    descEN: 'Equipped with ISO 9001 certified draw machines and multi-angle broadcast feeds ensuring 100% transparency and fairness in every single draw event.',
    descTH: 'ติดตั้งเครื่องออกรางวัลที่ได้รับการรับรองมาตรฐานสากล ISO 9001 พร้อมการถ่ายทอดสดหลายมุมกล้องเพื่อรับประกันความโปร่งใสและยุติธรรมแบบ 100% ในทุกครั้ง',
    descBN: 'ISO 9001 প্রত্যয়িত ড্র মেশিন এবং বহু-কোণ বিশিষ্ট সরাসরি সম্প্রচার দ্বারা সজ্জিত, যা প্রতিটি ড্র ইভেন্টে ১০০% স্বচ্ছতা এবং সততা নিশ্চিত করে।',
    date: '2026-06-16',
    locationEN: 'GLO Head Office Hall, Nonthaburi',
    locationTH: 'ห้องออกรางวัล สำนักงานสลากกินแบ่งรัฐบาล นนทบุรี',
    locationBN: 'জিএলও প্রধান কার্যালয় হল, ননথাবুরি',
    imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=1200&q=80',
    views: '14.2K'
  },
  {
    id: 'gal-2',
    categoryEN: 'Social Responsibility & CSR',
    categoryTH: 'ความรับผิดชอบต่อสังคม (CSR)',
    categoryBN: 'সামাজিক দায়বদ্ধতা ও সিএসআর',
    titleEN: 'Community Empowerment & Education Support',
    titleTH: 'โครงการสนับสนุนการศึกษาและพัฒนาชุมชนยั่งยืน',
    titleBN: 'কমিউনিটি ক্ষমতায়ন এবং শিক্ষা সহায়তা',
    descEN: 'Allocating national lottery proceeds to state healthcare, public schools, emergency relief funds, and local development programs nationwide.',
    descTH: 'การจัดสรรรายได้จากสลากกินแบ่งรัฐบาลเพื่อสนับสนุนโรงเรียน การสาธารณสุข และกองทุนบรรเทาสาธารณภัยเพื่อยกระดับคุณภาพชีวิตประชาชน',
    descBN: 'লটারির লভ্যাংশ দেশব্যাপী সরকারি স্বাস্থ্যসেবা, পাবলিক স্কুল, জরুরি ত্রাণ তহবিল এবং স্থানীয় উন্নয়ন কর্মসূচিতে বরাদ্দ করা।',
    date: '2026-06-25',
    locationEN: 'Provincial Learning Centers, Thailand',
    locationTH: 'ศูนย์การเรียนรู้ชุมชนประจำจังหวัด ทั่วประเทศ',
    locationBN: 'প্রাদেশিক শিক্ষা কেন্দ্র, থাইল্যান্ড',
    imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=80',
    views: '8.9K'
  },
  {
    id: 'gal-3',
    categoryEN: 'Cyber Security',
    categoryTH: 'ความปลอดภัยทางไซเบอร์',
    categoryBN: 'সাইবার নিরাপত্তা ও আইটি',
    titleEN: 'GLO Operations Security Command Center',
    titleTH: 'ศูนย์ควบคุมความมั่นคงปลอดภัยสารสนเทศตลอด 24 ชั่วโมง',
    titleBN: 'জিএলও অপারেশন সিকিউরিটি কমান্ড সেন্টার',
    descEN: 'State-of-the-art security systems, encrypted real-time digital ticket verification database, and fraud preventive telemetry analytics.',
    descTH: 'ระบบรักษาความปลอดภัยสารสนเทศขั้นสูง เฝ้าระวังภัยคุกคาม และฐานข้อมูลตรวจสอบความถูกต้องของสลากดิจิทัลแบบเรียลไทม์',
    descBN: 'অত্যাধুনিক নিরাপত্তা ব্যবস্থা, এনক্রিপ্ট করা রিয়েল-টাইম ডিজিটাল টিকিট যাচাইকরণ ডেটাবেস এবং প্রতারণা প্রতিরোধক বিশ্লেষণ কেন্দ্র।',
    date: '2026-06-28',
    locationEN: 'GLO Secure Data Center',
    locationTH: 'ศูนย์เทคโนโลยีสารสนเทศ สำนักงานสลากกินแบ่งรัฐบาล',
    locationBN: 'জিএলও নিরাপদ ডেটা সেন্টার',
    imageUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&q=80',
    views: '11.5K'
  },
  {
    id: 'gal-4',
    categoryEN: 'Digital Innovation',
    categoryTH: 'นวัตกรรมดิจิทัล',
    categoryBN: 'ডিজিটাল উদ্ভাবন ও অ্যাপস',
    titleEN: 'Mobile Scanning & Digital Ticket Portal Launch',
    titleTH: 'เปิดตัวแอปพลิเคชันสแกนสลากและซื้อขายสลากดิจิทัล',
    titleBN: 'মোবাইল স্ক্যানিং এবং ডিজিটাল টিকিট পোর্টাল চালু',
    descEN: 'Modern digital ticket system enables secure scans, purchase at official rates, direct wallet claim, and fast automatic prize matching.',
    descTH: 'ระบบสลากดิจิทัลที่ช่วยให้สแกน สั่งซื้อในราคาทางการ รับเงินรางวัลเข้ากระเป๋าเงินออนไลน์โดยตรง พร้อมตรวจผลอัตโนมัติรวดเร็ว',
    descBN: 'আধুনিক ডিজিটাল টিকিট সিস্টেম নিরাপদ স্ক্যান, সরকারি মূল্যে ক্রয়, সরাসরি ওয়ালেট দাবি এবং দ্রুত স্বয়ংক্রিয় পুরস্কার মিলানো নিশ্চিত করে।',
    date: '2026-06-12',
    locationEN: 'GLO Press Conference Room',
    locationTH: 'ห้องแถลงข่าว สำนักงานสลากกินแบ่งรัฐบาล',
    locationBN: 'জিএলও প্রেস কনফারেন্স রুম',
    imageUrl: 'https://images.unsplash.com/photo-1563013544-824ae1d704d3?auto=format&fit=crop&w=1200&q=80',
    views: '24.1K'
  },
  {
    id: 'gal-5',
    categoryEN: 'Organizational Excellence',
    categoryTH: 'ความเป็นเลิศขององค์กร',
    categoryBN: 'প্রাতিষ্ঠানিক শ্রেষ্ঠত্ব',
    titleEN: 'Annual GLO Governance & Integrity Awards',
    titleTH: 'พิธีมอบรางวัลการกำกับดูแลกิจการที่ดีและความโปร่งใสประจำปี',
    titleBN: 'বার্ষিক জিএলও গভর্নেন্স এবং সততা পুরস্কার',
    descEN: 'Celebrating our teams unyielding commitment to public service, anti-corruption standards, and top-tier transparent governance metrics.',
    descTH: 'เชิดชูเกียรติบุคลากรและทีมงานผู้ทุ่มเทรักษามาตรฐานความโปร่งใส ต่อต้านการทุจริต และยึดมั่นหลักธรรมาภิบาล',
    descBN: 'জনসেবা, দুর্নীতিবিরোধী মানদণ্ড এবং শীর্ষ স্তরের স্বচ্ছ শাসন ব্যবস্থার প্রতি আমাদের দলের অবিচল অঙ্গীকার উদযাপন।',
    date: '2026-06-30',
    locationEN: 'Grand Ballroom, Royal Thai Navy Convention Center',
    locationTH: 'หอประชุมกองทัพเรือ กรุงเทพมหานคร',
    locationBN: 'গ্র্যান্ড বলরুম, রয়্যাল থাই নেভি কনভেনশন সেন্টার',
    imageUrl: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80',
    views: '6.7K'
  }
];

export const ImageGallery: React.FC = () => {
  const { language } = useApp();
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  // Auto-play effect
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % GALLERY_IMAGES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length);
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % GALLERY_IMAGES.length);
  };

  const getLocalizedValue = (item: GalleryItem, field: 'category' | 'title' | 'desc' | 'location') => {
    if (language === 'TH') {
      if (field === 'category') return item.categoryTH;
      if (field === 'title') return item.titleTH;
      if (field === 'desc') return item.descTH;
      if (field === 'location') return item.locationTH;
    } else if (language === 'BN') {
      if (field === 'category') return item.categoryBN;
      if (field === 'title') return item.titleBN;
      if (field === 'desc') return item.descBN;
      if (field === 'location') return item.locationBN;
    }
    // Default to EN
    if (field === 'category') return item.categoryEN;
    if (field === 'title') return item.titleEN;
    if (field === 'desc') return item.descEN;
    return item.locationEN;
  };

  const currentItem = GALLERY_IMAGES[activeIndex];

  // Section heading translation
  const getSectionTitle = () => {
    if (language === 'TH') return 'ภาพข่าวสารและกิจกรรมของสำนักงาน GLO';
    if (language === 'BN') return 'জিএলও মিডিয়া ও ইভেন্ট গ্যালারি';
    return 'Official GLO Media & Event Gallery';
  };

  const getSectionSubtitle = () => {
    if (language === 'TH') return 'สำรวจบันทึกภาพกิจกรรม การดำเนินงาน และโครงการเพื่อสาธารณประโยชน์เพื่อความโปร่งใส';
    if (language === 'BN') return 'স্বচ্ছতার স্বার্থে জিএলও-এর সামাজিক কার্যক্রম, ড্র ইভেন্ট এবং প্রকল্পের ছবিগুলি দেখুন';
    return 'Explore the visual history of our operations, CSR programs, and commitment to transparent government lotteries.';
  };

  return (
    <section id="gallery" className="py-16 bg-slate-100 border-t border-b border-slate-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 text-center sm:text-left">
          <span className="text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-500/10 px-3 py-1.5 rounded-full inline-block mb-3 border border-amber-500/20">
            {language === 'TH' ? 'ความโปร่งใสในภาพถ่าย' : language === 'BN' ? 'গ্যালারি' : 'TRANS-IMAGE GALLERY'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {getSectionTitle()}
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-500 max-w-3xl leading-relaxed">
            {getSectionSubtitle()}
          </p>
        </div>

        {/* Carousel Showcase Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Side: Large Sliding Viewport (Col span 8) */}
          <div className="lg:col-span-8 flex flex-col justify-between bg-slate-950 rounded-3xl overflow-hidden shadow-xl border border-slate-800 relative group min-h-[400px] md:min-h-[480px]">
            
            {/* Background Image / Slide Transitions */}
            <div className="absolute inset-0 z-0">
              <AnimatePresence mode="wait">
                <motion.img
                  key={currentItem.id}
                  src={currentItem.imageUrl}
                  alt={getLocalizedValue(currentItem, 'title')}
                  className="w-full h-full object-cover opacity-85"
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 0.9, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.6 }}
                />
              </AnimatePresence>
              {/* Bottom and Top gradients for readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-slate-950/20 z-10" />
            </div>

            {/* Top Toolbar (Category Badge, Views, Fullscreen, Play/Pause) */}
            <div className="relative z-20 p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-2.5 py-1 rounded-md tracking-wider flex items-center gap-1 shadow">
                  <Tag className="h-3 w-3" />
                  {getLocalizedValue(currentItem, 'category')}
                </span>
                <span className="bg-slate-900/80 backdrop-blur-md text-slate-300 text-[10px] font-bold px-2.5 py-1 rounded-md flex items-center gap-1 border border-slate-700/50">
                  <Eye className="h-3.5 w-3.5 text-slate-400" />
                  {currentItem.views} {language === 'TH' ? 'ครั้ง' : language === 'BN' ? 'ভিউ' : 'views'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {/* Play/Pause Button */}
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-2 bg-slate-900/80 hover:bg-slate-800 text-white rounded-lg backdrop-blur-md transition-colors border border-slate-700/50"
                  title={isPlaying ? 'Pause' : 'Play'}
                  id="gallery-play-pause-btn"
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </button>
                {/* Fullscreen Trigger */}
                <button
                  onClick={() => setLightboxOpen(true)}
                  className="p-2 bg-slate-900/80 hover:bg-slate-800 text-white rounded-lg backdrop-blur-md transition-colors border border-slate-700/50"
                  title="Expand Full Screen"
                  id="gallery-fullscreen-btn"
                >
                  <Maximize2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Center navigation floating arrows (shown on hover on desktop) */}
            <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-between px-4 z-20 pointer-events-none">
              <button
                onClick={handlePrev}
                className="p-3 bg-slate-900/70 hover:bg-slate-900 text-white rounded-full backdrop-blur-sm pointer-events-auto transition-all transform hover:scale-105 opacity-0 group-hover:opacity-100 focus:opacity-100 border border-slate-700/40"
                id="gallery-prev-arrow"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={handleNext}
                className="p-3 bg-slate-900/70 hover:bg-slate-900 text-white rounded-full backdrop-blur-sm pointer-events-auto transition-all transform hover:scale-105 opacity-0 group-hover:opacity-100 focus:opacity-100 border border-slate-700/40"
                id="gallery-next-arrow"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>

            {/* Bottom Meta Overlay (Title, Description, Date, Location) */}
            <div className="relative z-20 p-6 md:p-8 space-y-3.5 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent">
              <div className="space-y-1.5">
                <h3 className="text-lg md:text-xl font-black text-white tracking-tight leading-tight">
                  {getLocalizedValue(currentItem, 'title')}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-2xl font-light">
                  {getLocalizedValue(currentItem, 'desc')}
                </p>
              </div>

              {/* Sub-Metadata Flexbox */}
              <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-[11px] text-slate-400 font-medium pt-2 border-t border-slate-800/60">
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-amber-400" />
                  {currentItem.date}
                </span>
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-amber-400" />
                  {getLocalizedValue(currentItem, 'location')}
                </span>
                <span className="ml-auto text-[10px] font-bold text-amber-500 uppercase tracking-wider">
                  Slide {activeIndex + 1} of {GALLERY_IMAGES.length}
                </span>
              </div>
            </div>

          </div>

          {/* Right Side: Active High Density List & Thumbnails Selector (Col span 4) */}
          <div className="lg:col-span-4 flex flex-col space-y-3">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col space-y-3 shadow-sm h-full justify-between">
              <div className="space-y-2">
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest border-b border-slate-100 pb-2">
                  {language === 'TH' ? 'รายการรูปภาพทั้งหมด' : language === 'BN' ? 'মিডিয়া তালিকা' : 'Gallery Playlist'}
                </h4>
                
                {/* Small Interactive Row Buttons for each slide */}
                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                  {GALLERY_IMAGES.map((img, idx) => (
                    <button
                      key={img.id}
                      onClick={() => {
                        setActiveIndex(idx);
                        setIsPlaying(false); // Pause auto-play when user clicks item
                      }}
                      className={`w-full text-left flex items-center gap-3 p-2 rounded-xl border transition-all text-xs ${
                        activeIndex === idx
                          ? 'bg-[#003366] text-white border-[#003366] shadow'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200/60'
                      }`}
                      id={`gallery-playlist-item-${idx}`}
                    >
                      {/* Miniature thumbnail */}
                      <div className="w-12 h-10 rounded-lg overflow-hidden flex-shrink-0 border border-black/10">
                        <img 
                          src={img.imageUrl} 
                          alt="" 
                          className="w-full h-full object-cover" 
                        />
                      </div>
                      {/* Short Title */}
                      <div className="overflow-hidden space-y-0.5">
                        <div className={`font-bold truncate ${activeIndex === idx ? 'text-amber-300' : 'text-slate-900'}`}>
                          {getLocalizedValue(img, 'title')}
                        </div>
                        <div className={`text-[10px] truncate ${activeIndex === idx ? 'text-slate-200' : 'text-slate-400'}`}>
                          {getLocalizedValue(img, 'category')}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Informative GLO message block */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 text-[10px] text-slate-500 leading-relaxed space-y-1 mt-auto">
                <div className="font-bold text-slate-800 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" />
                  {language === 'TH' ? 'สำนักเทคโนโลยีสารสนเทศ GLO' : language === 'BN' ? 'জিএলও আইটি তথ্য কেন্দ্র' : 'GLO IT Information Center'}
                </div>
                <p>
                  {language === 'TH' 
                    ? 'ภาพถ่ายทางประวัติศาสตร์และหลักฐานกระบวนการออกรางวัลได้รับการบันทึกและจัดเก็บถาวรเพื่อความโปร่งใสสูงสุดของประชาชน' 
                    : language === 'BN' 
                    ? 'সরকারি লটারি কার্যক্রমের সর্বোচ্চ স্বচ্ছতা বজায় রাখতে প্রতিটি ঘটনা রেকর্ড করা হয় এবং জনগণের জন্য উন্মুক্ত রাখা হয়।'
                    : 'Every major lottery operational milestone is recorded and safely archived under public records for peak transparency.'}
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Fullscreen Lightbox Overlay Modal */}
      <AnimatePresence>
        {lightboxOpen && (
          <motion.div 
            className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-slate-950/95 backdrop-blur-md p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Close Top button */}
            <button
              onClick={() => setLightboxOpen(false)}
              className="absolute top-5 right-5 p-2.5 bg-slate-800/80 hover:bg-slate-700 text-white rounded-full transition-colors backdrop-blur-md shadow-lg border border-slate-700"
              id="close-lightbox-btn"
            >
              <X className="h-6 w-6" />
            </button>

            {/* Left/Right Floating Arrows */}
            <div className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2">
              <button
                onClick={handlePrev}
                className="p-3 bg-slate-900/80 hover:bg-slate-800 text-white rounded-full transition-all hover:scale-105 border border-slate-700"
                id="lightbox-prev-btn"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
            </div>
            <div className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2">
              <button
                onClick={handleNext}
                className="p-3 bg-slate-900/80 hover:bg-slate-800 text-white rounded-full transition-all hover:scale-105 border border-slate-700"
                id="lightbox-next-btn"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            </div>

            {/* Image Container with maximum size constraint */}
            <div className="max-w-5xl w-full max-h-[75vh] relative rounded-2xl overflow-hidden shadow-2xl border border-slate-800 bg-slate-900 flex justify-center items-center">
              <img
                src={currentItem.imageUrl}
                alt={getLocalizedValue(currentItem, 'title')}
                className="max-h-[75vh] max-w-full object-contain"
              />
            </div>

            {/* Text details beneath image in Lightbox */}
            <div className="max-w-4xl w-full mt-6 text-center space-y-2 px-4">
              <span className="bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-3 py-1 rounded-full tracking-wider inline-block">
                {getLocalizedValue(currentItem, 'category')}
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                {getLocalizedValue(currentItem, 'title')}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl mx-auto font-light">
                {getLocalizedValue(currentItem, 'desc')}
              </p>
              
              <div className="flex justify-center items-center gap-6 text-[11px] text-slate-400 pt-3 max-w-xs mx-auto border-t border-slate-800">
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-amber-500" />
                  {currentItem.date}
                </span>
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-amber-500" />
                  {getLocalizedValue(currentItem, 'location')}
                </span>
              </div>
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
