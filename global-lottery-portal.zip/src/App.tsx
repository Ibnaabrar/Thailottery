import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AlertBar } from './components/AlertBar';
import { Header } from './components/Header';
import { HeroSlider } from './components/HeroSlider';
import { QuickServices } from './components/QuickServices';
import { ResultChecker } from './components/ResultChecker';
import { NewsSection } from './components/NewsSection';
import { ImageGallery } from './components/ImageGallery';
import { StatsSection } from './components/StatsSection';
import { WinnerShowcase } from './components/WinnerShowcase';
import { UserDashboard } from './components/UserDashboard';
import { DownloadApp } from './components/DownloadApp';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { GeminiBot } from './components/GeminiBot';

// Modals / Overlays
import { AuthModal } from './components/AuthModal';
import { PaymentGateway } from './components/PaymentGateway';
import { SearchModal } from './components/SearchModal';
import { AdminPanel } from './components/AdminPanel';

function AppContent() {
  const { theme } = useApp();
  
  return (
    <div className={`min-h-screen transition-colors duration-300 ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'} flex flex-col font-sans select-none scroll-smooth`}>
      
      {/* Urgent announcement ticker bar */}
      <AlertBar />

      {/* Sticky navigation header */}
      <Header />

      {/* Hero slider & Live draw countdown */}
      <HeroSlider />

      {/* Quick services cards grid */}
      <QuickServices />

      {/* Ticket result checker & Latest GLO board numbers */}
      <ResultChecker />

      {/* Winner stories & carousel showcase */}
      <WinnerShowcase />

      {/* Official news and announcements list */}
      <NewsSection />

      {/* Sliding Media & Event Image Gallery */}
      <ImageGallery />

      {/* Statistics performance counters dashboard */}
      <StatsSection />

      {/* User Account management dashboard */}
      <UserDashboard />

      {/* GLO mobile app download block */}
      <DownloadApp />

      {/* FAQs accordion list */}
      <FAQSection />

      {/* Government Footer legal details */}
      <Footer />

      {/* Floating AI chat assistant bot */}
      <GeminiBot />

      {/* Overlay Modals and CMS systems */}
      <AuthModal />
      <PaymentGateway />
      <SearchModal />
      <AdminPanel />

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
